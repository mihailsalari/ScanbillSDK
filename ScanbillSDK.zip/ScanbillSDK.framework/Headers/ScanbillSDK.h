//
//  ScanbillSDK.h
//  ScanbillSDK
//
//  Created by Mihail Salari on 8/22/18.
//  Copyright © 2018 ICS "Endava" SRL. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ScanbillSDK.
FOUNDATION_EXPORT double ScanbillSDKVersionNumber;

//! Project version string for ScanbillSDK.
FOUNDATION_EXPORT const unsigned char ScanbillSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ScanbillSDK/PublicHeader.h>
